@extends('layouts.app')

@section('content')

      <div class="conatiner-fluid content-inner mt-5 py-0">
      <div class="row">
         <div class="col-lg-12">
            <div class="iq-main">
               <div class="card mb-0 iq-content rounded-bottom">
                  <div class="d-flex flex-wrap align-items-center justify-content-between mx-3 my-3">
                     <div class="d-flex flex-wrap align-items-center">
                        <div class="profile-img22 position-relative me-3 mb-3 mb-lg-0">
                           <img src="{{asset('AdminUI/assets/images/avatars/01.png')}}" class="img-fluid avatar avatar-100 avatar-rounded" alt="profile-image">
                        </div>
                        <div class="d-flex align-items-center mb-3 mb-sm-0">
                           <div>
                              <h6 class="me-2 text-primary">{{Auth::user()->name}}</h6>
                              <span><svg width="19" height="19" class="me-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M21 10.8421C21 16.9172 12 23 12 23C12 23 3 16.9172 3 10.8421C3 4.76697 7.02944 1 12 1C16.9706 1 21 4.76697 21 10.8421Z" stroke="#07143B" stroke-width="1.5"/>
                                 <circle cx="12" cy="9" r="3" stroke="#07143B" stroke-width="1.5"/>
                                 </svg><small class="mb-0 text-dark">Bangalore</small></span>
                           </div>
                           <div class="ms-4">
                              <p class="mb-0 text-dark">Address</p>
                              <p class="me-2 mb-0 text-dark">{{Auth::user()->email}}</p>
                              <p class="mb-0 text-dark">Email</p>
                           </div> 
                        </div>
                     </div>
                     <!-- <ul class="d-flex mb-0 text-center ">
                        <li class="badge bg-soft-primary me-2">
                           <p class="mb-3 mt-2">142</p>
                           <h6 class="mb-1 fw-normal text-dark">Reviews</h6>
                        </li>
                        <li class="badge bg-soft-primary me-2">
                           <p class="mb-3 mt-2">201</p>
                           <h6 class="mb-1 fw-normal text-dark">Photos</h6>
                        </li>
                        <li class="badge bg-soft-primary">
                           <p class="mb-3 mt-2">3.1k</p>
                           <h6 class="mb-1 fw-normal text-dark">Followers</h6>
                        </li>
                     </ul> -->
                  </div>
               </div>
               <div class="iq-header-img">
                  <img src="{{asset('AdminUI/assets/images/user-profile/01.png')}}" alt="header" class="img-fluid w-100 rounded" style="object-fit: contain;">
               </div>
            </div>
         </div>
         
      </div>     
     </div>

     @endsection